module.exports = {
    token: "-",
    clientid: "-",
    prefix: "-",
    engine: "ytsearch",
    color: "#FF0000",
    mongodburl: "-",
    developers: ["-"],
    sharding: false,
    database: false,
    invite: "-",
    nodes: [
        {
            name: "nexa-1",
            host: "localhost",
            password: "password",
            port: 457,
            secure: false,
        },
    ]
}

/**
 * Project: Nexa Music
 * Author: KoDdy
 * Company: Infinity
 * This code is the property of EnourDev and may not be reproduced or
 * modified without permission. For more information, contact us at
 * https://discord.gg/fbu64BmPFD
 */